# Модуль OPAC-Global для сайта «АВРОРА» (Архив)

Архив содержит все компоненты электронного каталога OPAC для веб-сайта «Аврора».

## Структура файлов:
- `api/opac.php` — основной серверный шлюз, Rate Limiter, сессионный пул, авто-логин, парсинг MARC/XML, каскадный поиск
- `api/OpacClient.php` — объектно-ориентированный клиент OPAC-Global (PHP 7.1+)
- `src/opac_modal.js` — модуль модального окна поиска (ES6): карточки, обложки, филиалы, пагинация
- `src/opac_decoder.js` — декодер MARC/XML для фронтенда
- `src/opac_search.css` — стили модального окна каталога
- `assets/images/opac/` — векторные баннеры и обложки по умолчанию (`cosmo_no_cover.svg`, `catalog_banner.svg` и др.)
- `docs/opac_spec.json` — спецификация полей и индексов OPAC-Global
- `scripts/` — тестовые и генерационные скрипты (`test_opac_client.php`, `test_opac_search.php`, `generate_opac_assets.py`)
- `branches_cache.json` — справочник 18 библиотек-филиалов

## Инструкция по восстановлению:
1. Скопировать `api/*` в каталог `api/`
2. Скопировать `src/*` в каталог `src/`
3. Скопировать `assets/images/opac` в `assets/images/`
4. Подключить `<link rel="stylesheet" href="src/opac_search.css">` в `index.html`
5. Импортировать `initOpacModal` в `src/app.js`
