/* ── Каталог OPAC (ВРЕМЕННО НА ТЕХОБСЛУЖИВАНИИ ДЛЯ ЗАЩИТЫ СЕРВЕРА) ── */
const OPAC_MAINTENANCE = true;
const opacState = { query: '', page: 1, branch: '', onlyAvailable: false, totalPages: 1 };
let searchSeq = 0;

const BRANCH_CHIPS = [
    { v: '', label: 'Все' },
    { v: 'цгб', label: 'ЦГБ' },
    { v: 'цдб', label: 'ЦДБ' },
    { v: 'доброе', label: 'Доброе' },
    { v: 'ф4', label: 'Ф-4' },
    { v: 'ф1', label: 'Ф-1' },
    { v: 'ф10', label: 'Ф-10' },
    { v: 'ф13', label: 'Ф-13' },
];

function buildBranchChips() {
    const box = $('#branch-chips');
    if (!box) return;
    box.innerHTML = BRANCH_CHIPS.map((c, i) =>
        `<button class="chip${i === 0 ? ' is-active' : ''}" data-branch="${c.v}">${esc(c.label)}</button>`).join('');
    box.addEventListener('click', (e) => {
        const chip = e.target.closest('.chip');
        if (!chip) return;
        haptic('selection');
        $$('#branch-chips .chip').forEach(c => c.classList.remove('is-active'));
        chip.classList.add('is-active');
        opacState.branch = chip.dataset.branch;
        opacState.page = 1;
        runSearch();
    });
}

function selectBranchChip(branchVal) {
    const chip = $(`#branch-chips .chip[data-branch="${branchVal}"]`);
    if (chip) {
        $$('#branch-chips .chip').forEach(c => c.classList.remove('is-active'));
        chip.classList.add('is-active');
        opacState.branch = branchVal;
    }
}

function skeletons(count = 4) {
    $('#catalog-results').innerHTML = Array.from({ length: count }, () => `
        <div class="book-card">
            <div class="sk" style="width:72px;height:108px;flex-shrink:0;margin:0"></div>
            <div style="flex:1">
                <div class="sk sk-line" style="width:85%"></div>
                <div class="sk sk-line" style="width:55%"></div>
                <div class="sk sk-line" style="width:70%"></div>
            </div>
        </div>`).join('');
}

function emptyState(kind, customText = null) {
    const map = {
        empty: ['robot_sad', 'Космо ничего не нашёл', 'Попробуй изменить запрос или фильтры — в фондах АВРОРЫ ещё тысячи книг.', 'Сбросить фильтры'],
        error: ['robot_shock', 'Связь с каталогом потеряна', 'OPAC не ответил вовремя. Попробуй ещё раз через минуту.', 'Повторить'],
        limited: ['robot_sleep', 'Каталог отдыхает 60 секунд', 'Слишком много запросов подряд — дай OPAC передышку, потом жми «Повторить».', 'Повторить'],
    };
    const [img, title, text, btn] = map[kind] || map.empty;
    $('#catalog-results').innerHTML = `
        <div class="empty-state">
            <img src="${API.mascot}/${img}.png?v=4.64.2" alt="">
            <div class="empty-title">${title}</div>
            <div class="empty-text">${customText ? esc(customText) : text}</div>
            <button class="btn-cta" id="empty-retry">${btn}</button>
        </div>`;
    $('#empty-retry')?.addEventListener('click', () => {
        haptic('medium');
        opacState.page = 1;
        runSearch();
    });
}

function rateLimited() { emptyState('limited'); }

/* ── Хэширование строки в индекс темы (0..7) ── */
function getBookThemeIndex(str) {
    let hash = 0;
    const s = String(str || 'aurora');
    for (let i = 0; i < s.length; i++) {
        hash = ((hash << 5) - hash) + s.charCodeAt(i);
        hash |= 0;
    }
    return Math.abs(hash) % 8;
}

/* ── 8 тем виртуальных переплётов АВРОРЫ ── */
const BOOK_THEMES = [
    { id: 0, name: 'indigo',   bg1: '#1c1e4e', bg2: '#0c0e27', accent: '#38bdf8', glow: 'rgba(56, 189, 248, 0.35)', foil: '#a5f3fc' },
    { id: 1, name: 'emerald',  bg1: '#0c3629', bg2: '#051912', accent: '#10b981', glow: 'rgba(16, 185, 129, 0.35)', foil: '#6ee7b7' },
    { id: 2, name: 'purple',   bg1: '#35124c', bg2: '#180625', accent: '#c084fc', glow: 'rgba(192, 132, 252, 0.35)', foil: '#e9d5ff' },
    { id: 3, name: 'ruby',     bg1: '#460e22', bg2: '#20040f', accent: '#fb7185', glow: 'rgba(251, 113, 133, 0.35)', foil: '#fecdd3' },
    { id: 4, name: 'amber',    bg1: '#3c2406', bg2: '#1c1102', accent: '#fbbf24', glow: 'rgba(251, 191, 36, 0.35)', foil: '#fde68a' },
    { id: 5, name: 'sapphire', bg1: '#0b2545', bg2: '#041121', accent: '#38bdf8', glow: 'rgba(56, 189, 248, 0.35)', foil: '#bae6fd' },
    { id: 6, name: 'rose',     bg1: '#3a0f30', bg2: '#1a0415', accent: '#f472b6', glow: 'rgba(244, 114, 182, 0.35)', foil: '#fbcfe8' },
    { id: 7, name: 'teal',     bg1: '#0a343b', bg2: '#03181c', accent: '#2dd4bf', glow: 'rgba(45, 212, 191, 0.35)', foil: '#99f6e4' },
];

/* ── Нормализация сырых OPAC-заглавий ── */
function normalizeBookTitle(raw) {
    if (!raw) return 'Без названия';
    let t = String(raw).trim();

    // Исправление склеек («451по Фаренгейту»)
    t = t.replace(/\b451\s*по\s*фаренгейту\b/gi, '451° по Фаренгейту');
    t = t.replace(/(\d+)\s*([а-яА-ЯёЁ])/g, '$1 $2');

    // Устранение MARC-маркеров
    t = t.replace(/\[\s*текст\s*\]/gi, '');
    t = t.replace(/\/\s*\[?[^;\]]+\]?$/g, '');

    // Замена точек с запятой между произведениями на разделитель с точкой
    t = t.replace(/\s*;\s*/g, ' • ');

    // Очистка дублирующихся подзаголовков
    const parts = t.split(/\s*:\s*/);
    if (parts.length > 1) {
        const main = parts[0].trim();
        const sub = parts.slice(1).join(': ').trim();
        const wordsMain = main.toLowerCase().split(/\s+/);
        const wordsSub = sub.toLowerCase().split(/\s+/);
        const isDuplicate = wordsSub.every(w => wordsMain.includes(w)) || sub.length < 3;
        t = isDuplicate ? main : `${main}: ${sub}`;
    }

    t = t.replace(/[\s;:/.]+$/, '').trim();
    return t || 'Без названия';
}

/* ── Генератор DOM-компонента космической заглушки ── */
function createBookStubElement(title, author, isLarge = false) {
    const themeIdx = getBookThemeIndex((title || '') + (author || ''));
    const theme = BOOK_THEMES[themeIdx];
    const cleanTitle = normalizeBookTitle(title);
    const cleanAuthor = author ? author.replace(/\b[а-яА-ЯёЁ]\.\s*/g, '').trim() : '';

    const stub = document.createElement('div');
    stub.className = `aurora-book-stub theme-${theme.name} ${isLarge ? 'is-large' : ''}`;
    stub.style.setProperty('--stub-bg1', theme.bg1);
    stub.style.setProperty('--stub-bg2', theme.bg2);
    stub.style.setProperty('--stub-accent', theme.accent);
    stub.style.setProperty('--stub-glow', theme.glow);
    stub.style.setProperty('--stub-foil', theme.foil);

    stub.innerHTML = `
        <div class="stub-spine" aria-hidden="true"></div>
        <div class="stub-border-emboss" aria-hidden="true"></div>
        <div class="stub-inner">
            <div class="stub-brand">
                <span class="stub-brand-star">✦</span>
                <span class="stub-brand-text">АВРОРА</span>
                <span class="stub-brand-star">✦</span>
            </div>
            <div class="stub-emblem" aria-hidden="true">
                <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path>
                    <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path>
                    <circle cx="12" cy="9" r="2.5" fill="currentColor" opacity="0.3"></circle>
                    <path d="M12 5v1.5M12 11.5V13M8 9h1.5M14.5 9H16" opacity="0.6"></path>
                </svg>
            </div>
            <div class="stub-title" title="${esc(cleanTitle)}">${esc(cleanTitle)}</div>
            ${cleanAuthor ? `<div class="stub-author">${esc(cleanAuthor)}</div>` : ''}
        </div>
    `;
    return stub;
}

// Редирект на реальную обложку через серверный шлюз
function coverUrl(item) {
    const params = new URLSearchParams({
        action: 'cover',
        redirect: '1',
        title: item.title || '',
        author: item.author || '',
    });
    if (item.isbn) params.set('isbn', item.isbn);
    return `${API.opac}?${params.toString()}`;
}

/* ── Интеллектуальный парсинг и форматирование библиографического описания ── */
function parseBibliographicInfo(item) {
    const normTitle = normalizeBookTitle(item.title);
    const normAuthor = item.author ? item.author.trim() : '';
    const year = item.year || (item.imprint && (item.imprint.match(/\b(19\d\d|20\d\d)\b/) || [])[1]) || '';

    // Объём / количество страниц
    let pages = '';
    const imprintStr = item.imprint || (Array.isArray(item.shotform_raw) ? item.shotform_raw.join(' ') : '');
    const pagesMatch = imprintStr.match(/(\d+[\s,\[\]\d]*\s*(?:с|стр|с\.|c)\b)/i);
    if (pagesMatch) {
        pages = pagesMatch[1].replace(/c\b/i, 'с.').trim();
        if (!pages.endsWith('.')) pages += '.';
    }

    // Издательство и город
    let publisher = item.publisher || '';
    if (!publisher && imprintStr) {
        const pubMatch = imprintStr.match(/(?:[.-]\s*)([А-Яа-яA-Za-z\s.]+:\s*[А-Яа-яA-Za-z\s«»""—–-]+?)(?:,\s*\d{4}|\s*-\s*\d{4}|\.\s*-\s*\d{4})/);
        if (pubMatch) {
            publisher = pubMatch[1].trim();
        }
    }

    // Возрастной ценз (16+, 12+, 18+, 6+, 0+)
    let ageRating = '';
    const ageMatch = imprintStr.match(/\b(\d{1,2}\+)\b/);
    if (ageMatch) {
        ageRating = ageMatch[1];
    }

    // Тип издания (Однотомник, Многотомник, Собрание сочинений)
    let editionType = '';
    if (Array.isArray(item.shotform_raw)) {
        const rawJoined = item.shotform_raw.join(' ');
        if (/Однотомник/i.test(rawJoined)) editionType = 'Однотомник';
        else if (/Многотомник/i.test(rawJoined)) editionType = 'Многотомник';
        else if (/Собрание сочинений/i.test(rawJoined)) editionType = 'Собрание соч.';
    }

    // Номер тома / части
    let volume = '';
    const volMatch = imprintStr.match(/\b(Т\.\s*\d+|Том\s*\d+|Ч\.\s*\d+|Часть\s*\d+)\b/i);
    if (volMatch) {
        volume = volMatch[1];
    }

    // Шифр / ББК
    let shelfmark = item.shelfmark || '';
    if (!shelfmark && Array.isArray(item.copies)) {
        const found = item.copies.find(c => c.shifr && c.shifr !== 'Не задан');
        if (found) shelfmark = found.shifr;
    }
    if (!shelfmark && Array.isArray(item.shotform_raw)) {
        const rawJoined = item.shotform_raw.join(' ');
        const shMatch = rawJoined.match(/Шифр\s*([^;]+)/i);
        if (shMatch) shelfmark = shMatch[1].trim();
    }

    // Инвентарный номер
    let inventory = item.inventory || '';
    if (!inventory && Array.isArray(item.copies) && item.copies.length > 0) {
        inventory = item.copies[0].inventory || item.copies[0].code1 || '';
    }

    // Чистая библиографическая запись по ГОСТу
    let cleanCitation = '';
    if (item.outform) {
        cleanCitation = item.outform.replace(/\n+/g, ' ').trim();
    } else if (item.imprint) {
        cleanCitation = item.imprint.trim();
    } else {
        cleanCitation = `${normAuthor ? normAuthor + '. ' : ''}${normTitle}${year ? '.- ' + year : ''}`;
    }

    // Реальная аннотация (если есть)
    let annotation = item.annotation || '';
    if (!annotation && Array.isArray(item.shotform_raw)) {
        const descLines = item.shotform_raw.filter(l => 
            !l.includes('Инв.номер') && 
            !l.includes('Место хранения') && 
            !l.includes('Однотомник') && 
            !l.includes('Многотомник') &&
            l !== item.imprint
        );
        if (descLines.length > 0) {
            annotation = descLines.join(' ').trim();
        }
    }

    return {
        normTitle,
        normAuthor,
        year,
        pages,
        publisher,
        ageRating,
        editionType,
        volume,
        shelfmark,
        inventory,
        cleanCitation,
        annotation
    };
}

function renderItems(items) {
    currentSearchItems = items || [];
    opacItemsMap = {};
    const box = $('#catalog-results');
    if (!box) return;

    box.innerHTML = items.map((it, i) => {
        const idKey = it.id || ('item_' + i);
        opacItemsMap[idKey] = it;

        const normTitle = normalizeBookTitle(it.title);
        const normAuthor = it.author ? it.author.trim() : 'Автор не указан';
        const yearText = it.year ? ` • ${it.year} г.` : '';
        const shelfText = it.shelfmark ? `<span class="book-chip-shelf"><span class="material-symbols-rounded" style="font-size:11px;vertical-align:-1px">tag</span>${esc(it.shelfmark)}</span>` : '';
        const invText = it.inventory ? `<span class="book-chip-shelf"><span class="material-symbols-rounded" style="font-size:11px;vertical-align:-1px">barcode</span>№ ${esc(it.inventory)}</span>` : '';

        return `
        <article class="book-card" data-book-id="${esc(idKey)}" style="--stagger:${Math.min(i, 10)}">
            <div class="book-cover-container" data-title="${esc(it.title)}" data-author="${esc(it.author || '')}">
                <img class="book-cover" loading="lazy" src="${coverUrl(it)}" alt="${esc(normTitle)}">
            </div>
            <div class="book-info">
                <div class="book-title" title="${esc(normTitle)}">${esc(normTitle)}</div>
                <div class="book-author">${esc(normAuthor)}${esc(yearText)}</div>
                <div class="book-meta-row">
                    ${shelfText}
                    ${invText}
                </div>
            </div>
            <div class="book-card-arrow" aria-hidden="true">
                <span class="material-symbols-rounded">chevron_right</span>
            </div>
        </article>`;
    }).join('');

    // Подмена отсутствующих обложек на космические переплёты АВРОРЫ
    box.querySelectorAll('.book-cover-container').forEach(container => {
        const img = container.querySelector('img.book-cover');
        if (!img) return;
        img.addEventListener('error', () => {
            const title = container.dataset.title;
            const author = container.dataset.author;
            const stub = createBookStubElement(title, author, false);
            img.replaceWith(stub);
        }, { once: true });
    });

    // Обработка клика по карточке книги — открытие детальной шторки
    box.querySelectorAll('.book-card').forEach(card => {
        card.addEventListener('click', () => {
            const idKey = card.dataset.bookId;
            const item = opacItemsMap[idKey];
            if (item) {
                haptic('light');
                openBookSheet(item);
            }
        });
    });

    syncWindowSize();
}

/* ── Шторка деталей книги (Bottom Sheet) ── */
function openBookSheet(item) {
    const backdrop = $('#book-sheet-backdrop');
    const content = $('#book-sheet-content');
    if (!backdrop || !content) return;

    const copies = item.copies || [];
    const byBranch = {};
    copies.forEach(c => {
        const name = c.branch_name || c.location || 'Библиотека';
        byBranch[name] = byBranch[name] || {
            address: c.branch_address || '',
            phone: c.branch_phone || '',
            location: c.location || '',
        };
    });

    // Карточки филиалов (без меток наличия и количества экземпляров)
    const branchesHtml = Object.entries(byBranch).map(([name, b]) => {
        const cleanPhone = formatTelNumber(b.phone);

        return `
        <div class="sheet-branch-card">
            <div class="sheet-branch-header">
                <span class="sheet-branch-name">${esc(name)}</span>
            </div>
            ${b.address ? `<div class="sheet-branch-addr"><span class="material-symbols-rounded" style="font-size:13px;vertical-align:-2px">location_on</span> ${esc(b.address)}</div>` : ''}
            <div class="sheet-branch-actions">
                ${cleanPhone ? `<a class="branch-pill-btn branch-call-btn" href="tel:${cleanPhone}" target="_top" rel="noopener noreferrer" data-call-phone="${cleanPhone}" data-branch-name="${esc(name)}"><span class="material-symbols-rounded">call</span>Позвонить</a>` : ''}
                ${b.address ? `<button class="branch-card-btn" data-copy-addr="${esc(b.address)}"><span class="material-symbols-rounded">content_copy</span>Адрес</button>` : ''}
            </div>
        </div>`;
    }).join('') || '<div class="fine-print">Данные о филиалах уточняются в справочной службе ЦГБ.</div>';

    const biblio = parseBibliographicInfo(item);
    const normTitle = biblio.normTitle;
    const normAuthor = biblio.normAuthor || 'Автор не указан';

    // Карточки ключевых параметров книги (адаптивная сетка)
    const pills = [];
    if (biblio.year) {
        pills.push(`
        <div class="biblio-metric">
            <span class="biblio-metric-icon material-symbols-rounded">calendar_today</span>
            <div class="biblio-metric-content">
                <span class="biblio-metric-label">Год издания</span>
                <span class="biblio-metric-value">${esc(biblio.year)} г.</span>
            </div>
        </div>`);
    }
    if (biblio.pages) {
        pills.push(`
        <div class="biblio-metric">
            <span class="biblio-metric-icon material-symbols-rounded">menu_book</span>
            <div class="biblio-metric-content">
                <span class="biblio-metric-label">Объём</span>
                <span class="biblio-metric-value">${esc(biblio.pages)}</span>
            </div>
        </div>`);
    }
    if (biblio.publisher) {
        pills.push(`
        <div class="biblio-metric is-wide">
            <span class="biblio-metric-icon material-symbols-rounded">apartment</span>
            <div class="biblio-metric-content">
                <span class="biblio-metric-label">Издательство</span>
                <span class="biblio-metric-value">${esc(biblio.publisher)}</span>
            </div>
        </div>`);
    }
    if (biblio.shelfmark) {
        pills.push(`
        <div class="biblio-metric">
            <span class="biblio-metric-icon material-symbols-rounded">tag</span>
            <div class="biblio-metric-content">
                <span class="biblio-metric-label">ББК / Шифр</span>
                <span class="biblio-metric-value">${esc(biblio.shelfmark)}</span>
            </div>
        </div>`);
    }
    if (biblio.inventory) {
        pills.push(`
        <div class="biblio-metric">
            <span class="biblio-metric-icon material-symbols-rounded">barcode</span>
            <div class="biblio-metric-content">
                <span class="biblio-metric-label">Инв. номер</span>
                <span class="biblio-metric-value">№ ${esc(biblio.inventory)}</span>
            </div>
        </div>`);
    }
    if (biblio.editionType || biblio.volume) {
        const typeStr = [biblio.editionType, biblio.volume].filter(Boolean).join(' • ');
        pills.push(`
        <div class="biblio-metric">
            <span class="biblio-metric-icon material-symbols-rounded">auto_stories</span>
            <div class="biblio-metric-content">
                <span class="biblio-metric-label">Издание</span>
                <span class="biblio-metric-value">${esc(typeStr)}</span>
            </div>
        </div>`);
    }
    if (biblio.ageRating) {
        pills.push(`
        <div class="biblio-metric">
            <span class="biblio-metric-icon material-symbols-rounded">verified_user</span>
            <div class="biblio-metric-content">
                <span class="biblio-metric-label">Возраст</span>
                <span class="biblio-metric-value">${esc(biblio.ageRating)}</span>
            </div>
        </div>`);
    }

    content.innerHTML = `
        <div class="sheet-hero">
            <div class="sheet-cover-box" id="sheet-cover-container">
                <img src="${coverUrl(item)}" alt="${esc(normTitle)}">
            </div>
            <div class="sheet-meta-info">
                <div class="sheet-title">${esc(normTitle)}</div>
                <div class="sheet-author">${esc(normAuthor)}</div>
                ${biblio.year ? `<div class="sheet-imprint">${esc(biblio.year)} г.</div>` : ''}
                ${biblio.shelfmark ? `<div class="sheet-code">ББК/Шифр: <strong>${esc(biblio.shelfmark)}</strong></div>` : ''}
            </div>
        </div>

        <div class="sheet-actions">
            <button class="sheet-act-btn is-accent" id="sheet-btn-ask">
                <span class="material-symbols-rounded">chat_info</span>
                <span>Спросить Космо</span>
            </button>
            <button class="sheet-act-btn" id="sheet-btn-share">
                <span class="material-symbols-rounded">share</span>
                <span>Поделиться</span>
            </button>
            <button class="sheet-act-btn icon-only" id="sheet-btn-copy" aria-label="Скопировать краткую информацию" title="Скопировать краткую инфо">
                <span class="material-symbols-rounded">content_copy</span>
            </button>
        </div>

        <div class="sheet-biblio-block">
            <div class="sheet-biblio-head">
                <span class="sheet-section-title"><span class="material-symbols-rounded" style="font-size:15px;vertical-align:-2px;color:var(--aurora-cyan)">description</span> Описание издания</span>
                <button class="sheet-copy-citation-btn icon-only" id="sheet-btn-copy-citation" aria-label="Скопировать библиографическую запись" title="Скопировать библиографическую запись">
                    <span class="material-symbols-rounded">content_copy</span>
                </button>
            </div>

            ${pills.length > 0 ? `<div class="sheet-biblio-grid">${pills.join('')}</div>` : ''}

            ${biblio.cleanCitation ? `
            <div class="sheet-citation-card">
                <div class="sheet-citation-text">${esc(biblio.cleanCitation)}</div>
            </div>` : ''}

            ${biblio.annotation ? `
            <div class="sheet-annotation-box">
                <div class="sheet-annotation-label"><span class="material-symbols-rounded">format_quote</span> Аннотация</div>
                <div class="sheet-annotation-text">${esc(biblio.annotation)}</div>
            </div>` : ''}
        </div>

        <div>
            <div class="sheet-section-title"><span class="material-symbols-rounded" style="font-size:15px;vertical-align:-2px;color:var(--aurora-cyan)">domain</span> Где найти книгу в библиотеках города</div>
            <div class="sheet-branches-list">${branchesHtml}</div>
        </div>
    `;

    // Подмена отсутствующей обложки в шторке на крупный виртуальный переплёт
    const sheetImg = $('#sheet-cover-container img');
    if (sheetImg) {
        sheetImg.addEventListener('error', () => {
            const stub = createBookStubElement(item.title, item.author, true);
            sheetImg.replaceWith(stub);
        }, { once: true });
    }

    // Копирование адреса филиала
    content.querySelectorAll('[data-copy-addr]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            copyText(btn.dataset.copyAddr);
            toast('Адрес скопирован в буфер 📋');
            haptic('light');
        });
    });

    // Телефонные вызовы из шторки (активация звонка на смартфоне)
    content.querySelectorAll('[data-call-phone]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            initiatePhoneCall(btn.dataset.callPhone, btn.dataset.branchName || '');
        });
    });

    // Копирование библиографической записи
    $('#sheet-btn-copy-citation')?.addEventListener('click', (e) => {
        e.stopPropagation();
        const fullCitation = biblio.cleanCitation || `${normAuthor}. ${normTitle}${biblio.year ? '.- ' + biblio.year : ''}`;
        copyText(fullCitation);
        toast('Библиографическая запись скопирована 📋');
        haptic('light');
    });

    // Действия шторки: спросить Космо
    $('#sheet-btn-ask')?.addEventListener('click', (e) => {
        e.stopPropagation();
        haptic('medium');
        // Закрываем шторку без history.back(), чтобы popstate не сбил переход в чат
        closeBookSheet(false);
        const bTitle = normalizeBookTitle(item.title);
        const bAuthor = item.author ? item.author.trim() : 'автор не указан';
        const promptText = `Расскажи о книге «${bTitle}» (${bAuthor}): о чём она и кому будет интересна?`;
        goto('chat');
        setTimeout(() => {
            sendChat(promptText);
        }, 120);
    });

    $('#sheet-btn-share')?.addEventListener('click', async () => {
        haptic('light');
        const text = `📖 «${normTitle}» — ${normAuthor}\nКнига найдена в каталоге библиотек Владимира (ЦБС).\nИщи в приложении АВРОРА • Космо!`;
        try {
            if (bridgeReady && window.vkBridge) {
                await window.vkBridge.send('VKWebAppShare', { link: window.location.href });
                haptic('success');
                return;
            }
        } catch (e) {}
        copyText(text);
        toast('Информация о книге скопирована 📋');
    });

    $('#sheet-btn-copy')?.addEventListener('click', () => {
        const text = `${normTitle} — ${normAuthor} ${biblio.year ? '(' + biblio.year + ')' : ''}${biblio.shelfmark ? ' [ББК: ' + biblio.shelfmark + ']' : ''}`;
        copyText(text);
        toast('Название и шифр скопированы 📋');
        haptic('light');
    });

    backdrop.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
    haptic('light');
    syncWindowSize(980);

    if (window.vkBridge) {
        window.vkBridge.send('VKWebAppDisableSwipeBack').catch(() => {});
    }

    try {
        history.pushState({ modal: 'book' }, '', location.hash);
    } catch (e) {}
}

function closeBookSheet(popHist = true) {
    const backdrop = $('#book-sheet-backdrop');
    if (!backdrop || backdrop.classList.contains('hidden')) return;
    backdrop.classList.add('hidden');
    document.body.style.overflow = '';
    haptic('light');
    syncWindowSize();

    if (window.vkBridge) {
        window.vkBridge.send('VKWebAppEnableSwipeBack').catch(() => {});
    }

    if (popHist && history.state?.modal === 'book') {
        history.back();
    }
}

function initSheetSwipeGesture() {
    const sheet = $('#book-sheet');
    const handle = $('#book-sheet-handle');
    if (!sheet || !handle) return;

    let startY = 0;
    let currentY = 0;
    let isDragging = false;
    let startTime = 0;

    const onPointerDown = (e) => {
        if (!e.target.closest('#book-sheet-handle') && !e.target.closest('.sheet-top-bar')) return;
        isDragging = true;
        startY = e.clientY || e.touches?.[0]?.clientY || 0;
        currentY = startY;
        startTime = Date.now();
        sheet.style.transition = 'none';
    };

    const onPointerMove = (e) => {
        if (!isDragging) return;
        const clientY = e.clientY || e.touches?.[0]?.clientY || 0;
        const deltaY = clientY - startY;
        if (deltaY > 0) {
            currentY = clientY;
            sheet.style.transform = `translateY(${deltaY}px)`;
            if (e.cancelable) e.preventDefault();
        }
    };

    const onPointerUp = () => {
        if (!isDragging) return;
        isDragging = false;
        sheet.style.transition = 'transform 260ms var(--ease-spring)';
        const deltaY = currentY - startY;
        const timeDiff = Math.max(Date.now() - startTime, 1);
        const velocity = deltaY / timeDiff;

        if (deltaY > 90 || velocity > 0.4) {
            sheet.style.transform = 'translateY(100%)';
            setTimeout(() => {
                closeBookSheet();
                sheet.style.transform = '';
            }, 200);
        } else {
            sheet.style.transform = 'translateY(0)';
        }
    };

    handle.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointermove', onPointerMove, { passive: false });
    window.addEventListener('pointerup', onPointerUp);
    window.addEventListener('pointercancel', onPointerUp);
}

$('#book-sheet-close')?.addEventListener('click', () => closeBookSheet());
$('#book-sheet-backdrop')?.addEventListener('click', (e) => {
    if (e.target === $('#book-sheet-backdrop')) closeBookSheet();
});

async function runSearch() {
    if (OPAC_MAINTENANCE) {
        toast('Каталог OPAC временно на техобслуживании');
        const welcome = $('#catalog-welcome');
        if (welcome) welcome.classList.remove('hidden');
        $('#catalog-results').innerHTML = `
            <div class="empty-state" style="padding: 24px 16px;">
                <div class="empty-emoji" style="font-size: 38px;">🛠️</div>
                <div class="empty-title" style="color: #fbbf24; margin-top: 8px;">Технические работы на сервере OPAC</div>
                <div class="empty-desc" style="color: var(--text-sub); font-size: 13px; line-height: 1.5; margin-top: 6px;">
                    Поисковые запросы временно приостановлены для защиты сервера библиотеки от перегрузки.
                </div>
            </div>
        `;
        $('#opac-pager')?.classList.add('hidden');
        $('#results-meta')?.classList.add('hidden');
        syncWindowSize();
        return;
    }

    const q = opacState.query.trim();
    const welcome = $('#catalog-welcome');
    if (!q) {
        if (welcome) welcome.classList.remove('hidden');
        $('#catalog-results').innerHTML = '';
        $('#opac-pager')?.classList.add('hidden');
        $('#results-meta')?.classList.add('hidden');
        syncWindowSize();
        return;
    }

    // При начале поиска крупный блок Космо скрывается
    if (welcome) welcome.classList.add('hidden');

    const seq = ++searchSeq;
    skeletons();
    $('#opac-pager')?.classList.add('hidden');
    try {
        const params = new URLSearchParams({
            action: 'search', query: q, page: opacState.page, length: 6, include_copies: '1',
        });
        if (opacState.branch) params.set('branch', opacState.branch);
        if (opacState.onlyAvailable) params.set('only_available', '1');

        const r = await fetch(`${API.opac}?${params}`);
        const d = await r.json();
        if (seq !== searchSeq) return;

        if (d.rate_limited || r.status === 429) {
            rateLimited();
            haptic('warning');
            return;
        }
        if (d.ok === false) {
            emptyState('error', d.error || 'Каталог временно недоступен');
            haptic('error');
            return;
        }
        const items = d.items || [];
        if (!items.length) {
            emptyState('empty');
            return;
        }

        renderItems(items);
        const meta = $('#results-meta');
        if (meta) {
            meta.classList.remove('hidden');
            meta.textContent = `Найдено: ${d.total_found} • страница ${d.page} из ${d.total_pages || 1}`;
        }
        opacState.totalPages = d.total_pages || 1;
        if ($('#opac-page-label')) $('#opac-page-label').textContent = `${d.page} / ${d.total_pages || 1}`;
        $('#opac-pager')?.classList.remove('hidden');
        if ($('#opac-prev')) $('#opac-prev').disabled = d.page <= 1;
        if ($('#opac-next')) $('#opac-next').disabled = d.page >= (d.total_pages || 1);
        haptic('success');
    } catch (e) {
        if (seq !== searchSeq) return;
        emptyState('error');
        haptic('error');
    }
}

function initCatalog() {
    buildBranchChips();
    let deb;
    $('#opac-query')?.addEventListener('input', (e) => {
        opacState.query = e.target.value;
        $('#opac-clear')?.classList.toggle('hidden', !e.target.value);
        clearTimeout(deb);
        deb = setTimeout(() => { opacState.page = 1; runSearch(); }, 450);
    });
    $('#opac-query')?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            clearTimeout(deb);
            opacState.query = e.target.value;
            opacState.page = 1;
            $('#opac-clear')?.classList.toggle('hidden', !e.target.value);
            e.target.blur();
            runSearch();
        }
    });
    $('#opac-clear')?.addEventListener('click', () => {
        clearTimeout(deb);
        $('#opac-query').value = '';
        opacState.query = '';
        $('#opac-clear').classList.add('hidden');
        haptic('light');
        runSearch();
    });

    // Быстрые подсказки-чипы под крупным Космо
    $$('[data-search-hint]').forEach(btn => {
        if (OPAC_MAINTENANCE) {
            btn.style.opacity = '0.5';
            btn.style.cursor = 'not-allowed';
        }
        btn.addEventListener('click', () => {
            if (OPAC_MAINTENANCE) {
                toast('Каталог OPAC временно на техобслуживании');
                return;
            }
            const hint = btn.dataset.searchHint;
            const input = $('#opac-query');
            if (input) {
                input.value = hint;
                $('#opac-clear')?.classList.remove('hidden');
                opacState.query = hint;
                opacState.page = 1;
                haptic('light');
                runSearch();
            }
        });
    });

    $('#opac-prev')?.addEventListener('click', () => {
        if (opacState.page > 1) {
            opacState.page--;
            haptic('selection');
            runSearch();
        }
    });
    $('#opac-next')?.addEventListener('click', () => {
        if (opacState.page < opacState.totalPages) {
            opacState.page++;
            haptic('selection');
            runSearch();
        }
    });
}

